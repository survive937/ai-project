import pytesseract
from PIL import Image

class ImageRecognizer:
    def __init__(self):
        # No model needed for OCR approach
        pass

    def recognize_image(self, image_path):
        try:
            img = Image.open(image_path)
            text = pytesseract.image_to_string(img)
            ingredients = self.extract_ingredients(text)
            return ingredients
        except Exception as e:
            print(f"Error in image recognition: {e}")
            return []

    def extract_ingredients(self, text):
        # Basic example: split lines and filter by common ingredient words
        common_ingredients = {
            'chicken', 'broccoli', 'rice', 'tomato', 'carrot', 'lettuce',
            'apple', 'banana', 'butter', 'egg', 'flour', 'sugar', 'milk',
            'oil', 'garlic', 'onion', 'pepper', 'salt', 'spinach', 'mushroom',
            'fish', 'shrimp', 'pasta', 'beans', 'peas', 'cheese', 'olive',
            'steak', 'cucumber', 'orange', 'lemon', 'strawberry'
        }
        lines = text.lower().split('\n')
        found = set()
        for line in lines:
            words = line.split()
            for word in words:
                w = word.strip(",.;:")
                if w in common_ingredients:
                    found.add(w)
        return list(found)
